Music Vibe Discovery — Browser Song Tagger

Run locally:
1. Unzip this folder.
2. Double-click index.html.
3. Use Pop New Song to fetch songs.
4. Add tags/moods and save.
5. Export JSON or CSV for backups.

This app is fully browser-only. There is no Python, Node, Flask, or backend server.
Data is saved in your browser localStorage.

New import/queue behaviour:
- You can import multiple JSON save files at once.
- Imports merge into your current browser database instead of replacing it.
- Matching songs are merged by iTunes track ID when available, otherwise by artist + title.
- Existing local saves are preserved; arrays like mood/tags are combined.
- Popped songs are kept in a review queue until you save or clear them.
- Importing JSON does not clear saved songs or the popped song queue.
